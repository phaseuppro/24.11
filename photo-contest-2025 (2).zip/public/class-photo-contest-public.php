<?php
class Photo_Contest_Public {
    private $plugin_name;
    private $version;

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;

        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    public function enqueue_styles() {
        wp_enqueue_style(
            $this->plugin_name . '-submission',
            plugin_dir_url(__FILE__) . 'css/submission-style.css',
            array(),
            $this->version,
            'all'
        );
    }

    public function enqueue_scripts() {
        wp_enqueue_script(
            $this->plugin_name . '-validation',
            plugin_dir_url(__FILE__) . 'js/submission-validation.js',
            array('jquery'),
            $this->version,
            true
        );

        wp_localize_script(
            $this->plugin_name . '-validation',
            'photoContestSubmission',
            array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('photo_contest_submission'),
                'maxFileSize' => 5 * 1024 * 1024,
                'messages' => array(
                    'fileTooLarge' => 'File size must be less than 5MB',
                    'invalidType' => 'Please upload a valid image file',
                    'uploading' => 'Uploading...'
                )
            )
        );
    }

    public function register_shortcodes() {
        add_shortcode('photo_contest', array($this, 'render_contest'));
        add_shortcode('photo_submission', array($this, 'render_submission_form'));
        add_shortcode('photo_gallery', array($this, 'render_gallery'));
    }

    public function render_contest($atts) {
        $atts = shortcode_atts(array(
            'id' => 0,
            'view' => 'gallery'
        ), $atts);

        ob_start();
        include PHOTO_CONTEST_PATH . 'public/templates/contest-display.php';
        return ob_get_clean();
    }

    public function render_submission_form($atts) {
        $atts = shortcode_atts(array(
            'contest_id' => 0
        ), $atts);

        ob_start();
        include PHOTO_CONTEST_PATH . 'public/templates/submission-form.php';
        return ob_get_clean();
    }

    public function render_gallery($atts) {
        $atts = shortcode_atts(array(
            'contest_id' => 0,
            'limit' => 12
        ), $atts);

        ob_start();
        include PHOTO_CONTEST_PATH . 'public/templates/gallery.php';
        return ob_get_clean();
    }
}
