<?php
if (!defined('ABSPATH')) exit;

$contest_id = $atts['contest_id'];
$contest = $this->contest_manager->get_contest($contest_id);
$winners = $this->contest_manager->get_contest_winners($contest_id, 3);
?>

<div class="photo-contest-results">
    <h2><?php echo esc_html($contest->title); ?> - Results</h2>
    
    <?php if ($winners): ?>
        <div class="winners-podium">
            <?php foreach ($winners as $position => $winner): ?>
                <div class="winner position-<?php echo esc_attr($position + 1); ?>">
                    <div class="winner-photo">
                        <img src="<?php echo esc_url($winner->photo_url); ?>" 
                             alt="<?php echo esc_attr($winner->title); ?>">
                        <span class="position-badge"><?php echo esc_html($position + 1); ?></span>
                    </div>
                    <div class="winner-info">
                        <h3><?php echo esc_html($winner->title); ?></h3>
                        <p class="photographer">By <?php echo esc_html(get_userdata($winner->user_id)->display_name); ?></p>
                        <p class="votes"><?php echo esc_html($winner->votes_count); ?> votes</p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="no-results">No results available yet.</p>
    <?php endif; ?>
</div>
