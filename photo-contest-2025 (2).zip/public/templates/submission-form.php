<?php
if (!defined('ABSPATH')) exit;

$contest_id = get_query_var('contest_id');
$contest = $this->contest_manager->get_contest($contest_id);
?>

<div class="photo-contest-submission-form">
    <h2>Submit Your Photo</h2>
    
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
        <input type="hidden" name="action" value="submit_photo_contest">
        <input type="hidden" name="contest_id" value="<?php echo esc_attr($contest_id); ?>">
        <?php wp_nonce_field('submit_photo_contest', 'photo_contest_nonce'); ?>

        <div class="form-field">
            <label for="photo-title">Photo Title *</label>
            <input type="text" id="photo-title" name="photo_title" required>
        </div>

        <div class="form-field">
            <label for="photo-description">Description</label>
            <textarea id="photo-description" name="photo_description" rows="4"></textarea>
        </div>

        <div class="form-field">
            <label for="photo-file">Upload Photo *</label>
            <input type="file" id="photo-file" name="photo_file" accept="image/*" required>
        </div>

        <button type="submit" class="submit-button">Submit Photo</button>
    </form>
</div>
