<?php
if (!defined('ABSPATH')) exit;

$contest_id = $atts['contest_id'];
$columns = intval($atts['columns']);
$submissions = $this->contest_manager->get_contest_submissions($contest_id);
?>

<div class="photo-contest-gallery columns-<?php echo esc_attr($columns); ?>">
    <h2><?php echo esc_html($contest->title); ?> - Gallery</h2>
    
    <?php if ($submissions): ?>
        <div class="gallery-grid">
            <?php foreach ($submissions as $submission): ?>
                <div class="gallery-item">
                    <div class="photo-wrapper">
                        <img src="<?php echo esc_url($submission->photo_url); ?>" 
                             alt="<?php echo esc_attr($submission->title); ?>">
                    </div>
                    <div class="photo-info">
                        <h3><?php echo esc_html($submission->title); ?></h3>
                        <p class="photo-description"><?php echo esc_html($submission->description); ?></p>
                        <div class="photo-meta">
                            <span class="votes-count"><?php echo esc_html($submission->votes_count); ?> votes</span>
                            <?php if ($contest->status === 'active'): ?>
                                <button class="vote-button" data-submission-id="<?php echo esc_attr($submission->id); ?>">
                                    Vote
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="no-submissions">No photos submitted yet.</p>
    <?php endif; ?>
</div>
