jQuery(document).ready(function($) {
    // Contest deletion confirmation
    $('.delete-contest').on('click', function(e) {
        if (!confirm('Are you sure you want to delete this contest?')) {
            e.preventDefault();
        }
    });

    // Date picker initialization
    if ($.fn.datepicker) {
        $('.contest-date').datepicker({
            dateFormat: 'yy-mm-dd',
            minDate: 0
        });
    }

    // Form validation
    $('#new-contest-form').on('submit', function(e) {
        var title = $('#contest-title').val();
        var startDate = $('#start-date').val();
        var endDate = $('#end-date').val();

        if (!title || !startDate || !endDate) {
            e.preventDefault();
            alert('Please fill in all required fields');
        }
    });
});
