<?php
class Photo_Contest_Settings {
    private $option_name = 'photo_contest_email_settings';

    public function __construct() {
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
        require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-defaults.php';
    }

    public function add_settings_page() {
        add_submenu_page(
            'edit.php?post_type=photo_contest',
            __('Email Settings', 'photo-contest'),
            __('Email Settings', 'photo-contest'),
            'manage_options',
            'photo-contest-settings',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting(
            $this->option_name, 
            $this->option_name,
            array($this, 'sanitize_settings')
        );

        add_settings_section(
            'email_templates',
            __('Email Templates', 'photo-contest'),
            array($this, 'render_section_info'),
            'photo-contest-settings'
        );

        $this->add_email_template_fields();
    }

    private function add_email_template_fields() {
        $templates = array(
            'submission_approved' => __('Submission Approved Email', 'photo-contest'),
            'winner_notification' => __('Winner Notification Email', 'photo-contest'),
            'admin_notification' => __('Admin Notification Email', 'photo-contest')
        );

        foreach ($templates as $key => $label) {
            add_settings_field(
                $key . '_subject',
                $label . ' ' . __('Subject', 'photo-contest'),
                array($this, 'render_text_field'),
                'photo-contest-settings',
                'email_templates',
                array('field' => $key . '_subject')
            );

            add_settings_field(
                $key . '_template',
                $label . ' ' . __('Template', 'photo-contest'),
                array($this, 'render_textarea_field'),
                'photo-contest-settings',
                'email_templates',
                array('field' => $key . '_template')
            );
        }
    }

    public function sanitize_settings($input) {
        $sanitized = array();
        $default_templates = Photo_Contest_Defaults::get_default_templates();

        foreach ($input as $key => $value) {
            if (strpos($key, '_subject')) {
                $sanitized[$key] = sanitize_text_field($value);
            } else {
                $sanitized[$key] = wp_kses_post($value);
            }
        }

        // Use defaults for empty template fields
        foreach ($default_templates as $key => $default_value) {
            if (empty($sanitized[$key . '_template'])) {
                $sanitized[$key . '_template'] = $default_value;
            }
        }

        return $sanitized;
    }

    public function render_settings_page() {
        require_once plugin_dir_path(__FILE__) . 'partials/admin-settings.php';
    }

    public function render_section_info() {
        echo '<p>' . __('Customize email templates for different notifications. Available variables: {user_name}, {contest_title}, {photo_title}, {position}', 'photo-contest') . '</p>';
    }

    public function render_text_field($args) {
        $options = get_option($this->option_name);
        $value = isset($options[$args['field']]) ? $options[$args['field']] : '';
        ?>
        <input type="text" 
               name="<?php echo esc_attr($this->option_name . '[' . $args['field'] . ']'); ?>" 
               value="<?php echo esc_attr($value); ?>" 
               class="regular-text">
        <?php
    }

    public function render_textarea_field($args) {
        $options = get_option($this->option_name);
        $value = isset($options[$args['field']]) ? $options[$args['field']] : '';
        ?>
        <textarea name="<?php echo esc_attr($this->option_name . '[' . $args['field'] . ']'); ?>" 
                  rows="10" 
                  class="large-text"><?php echo esc_textarea($value); ?></textarea>
        <?php
    }
}
