<?php if (!defined('ABSPATH')) exit; ?>
<div class="tablenav top">
    <div class="alignleft actions bulkactions">
        <select name="bulk-action">
            <option value="">Bulk Actions</option>
            <option value="approve">Approve</option>
            <option value="reject">Reject</option>
        </select>
        <button class="button action" id="doaction">Apply</button>
    </div>
    <div class="alignright">
        <form method="get" class="search-form">
            <input type="hidden" name="page" value="photo-contest-submissions">
            <input type="hidden" name="contest_id" value="<?php echo esc_attr($contest_id); ?>">
            <input type="search" name="s" value="<?php echo get_search_query(); ?>">
            <input type="submit" class="button" value="Search Submissions">
        </form>
    </div>
</div>
<div class="wrap photo-contest-admin">
    <h1>
        <?php echo esc_html(sprintf('Submissions for %s', $contest ? $contest->title : '')); ?>
    </h1>

    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Photo</th>
                <th>Title</th>
                <th>Participant</th>
                <th>Submission Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($submissions)): ?>
                <?php foreach ($submissions as $submission): ?>
                    <tr>
                        <td>
                            <img src="<?php echo esc_url($submission->photo_url); ?>" 
                                 alt="<?php echo esc_attr($submission->title); ?>" 
                                 style="max-width: 100px;">
                        </td>
                        <td><?php echo esc_html($submission->title); ?></td>
                        <td><?php echo esc_html($submission->participant_name); ?></td>
                        <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($submission->submission_date))); ?></td>
                        <td><?php echo esc_html(ucfirst($submission->status)); ?></td>
                        <td>
                            <button class="button button-small approve-submission" 
                                    data-submission-id="<?php echo esc_attr($submission->id); ?>">
                                Approve
                            </button>
                            <button class="button button-small reject-submission" 
                                    data-submission-id="<?php echo esc_attr($submission->id); ?>">
                                Reject
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No submissions found for this contest.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
