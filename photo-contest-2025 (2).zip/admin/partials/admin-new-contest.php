<div class="wrap">
    <h1><?php echo esc_html__('Add New Contest', 'photo-contest'); ?></h1>
    
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <?php wp_nonce_field('create_photo_contest', 'photo_contest_nonce'); ?>
        <input type="hidden" name="action" value="create_photo_contest">
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="contest_title"><?php echo esc_html__('Contest Title', 'photo-contest'); ?></label>
                </th>
                <td>
                    <input type="text" id="contest_title" name="contest_title" class="regular-text" required>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="contest_description"><?php echo esc_html__('Description', 'photo-contest'); ?></label>
                </th>
                <td>
                    <?php wp_editor('', 'contest_description', array('textarea_rows' => 5)); ?>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="start_date"><?php echo esc_html__('Start Date', 'photo-contest'); ?></label>
                </th>
                <td>
                    <input type="datetime-local" id="start_date" name="start_date" required>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="end_date"><?php echo esc_html__('End Date', 'photo-contest'); ?></label>
                </th>
                <td>
                    <input type="datetime-local" id="end_date" name="end_date" required>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="contest_status"><?php echo esc_html__('Status', 'photo-contest'); ?></label>
                </th>
                <td>
                    <select id="contest_status" name="contest_status">
                        <option value="draft"><?php echo esc_html__('Draft', 'photo-contest'); ?></option>
                        <option value="published"><?php echo esc_html__('Published', 'photo-contest'); ?></option>
                    </select>
                </td>
            </tr>
        </table>
        
        <?php submit_button(__('Create Contest', 'photo-contest')); ?>
    </form>
</div>
