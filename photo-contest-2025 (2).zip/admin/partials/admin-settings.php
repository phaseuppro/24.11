<?php if (!defined('ABSPATH')) exit; ?>

<div class="wrap photo-contest-settings-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <div id="settings-saved-notice" class="notice notice-success" style="display:none;">
        <p><?php _e('Settings saved successfully!', 'photo-contest'); ?></p>
    </div>

    <div id="settings-error-notice" class="notice notice-error" style="display:none;">
        <p><?php _e('Error saving settings.', 'photo-contest'); ?></p>
    </div>

    <form method="post" action="options.php" id="photo-contest-settings-form">
        <?php
        settings_fields('photo_contest_email_settings');
        do_settings_sections('photo-contest-settings');
        ?>

        <div class="template-section">
            <h2><?php _e('Email Templates', 'photo-contest'); ?></h2>
            
            <!-- Submission Approved Template -->
            <div class="email-template">
                <h3><?php _e('Submission Approved Email', 'photo-contest'); ?></h3>
                <div class="variables-list">
                    <?php _e('Available variables:', 'photo-contest'); ?>
                    <button type="button" class="insert-variable button" data-variable="user_name">{user_name}</button>
                    <button type="button" class="insert-variable button" data-variable="contest_title">{contest_title}</button>
                    <button type="button" class="insert-variable button" data-variable="photo_title">{photo_title}</button>
                </div>
                <textarea id="submission_approved_template" name="photo_contest_email_settings[submission_approved_template]" rows="10" class="large-text"><?php echo esc_textarea(get_option('photo_contest_email_settings')['submission_approved_template'] ?? ''); ?></textarea>
                <button type="button" class="preview-template button" data-template="submission_approved"><?php _e('Preview', 'photo-contest'); ?></button>
            </div>

            <!-- Winner Notification Template -->
            <div class="email-template">
                <h3><?php _e('Winner Notification Email', 'photo-contest'); ?></h3>
                <div class="variables-list">
                    <button type="button" class="insert-variable button" data-variable="user_name">{user_name}</button>
                    <button type="button" class="insert-variable button" data-variable="contest_title">{contest_title}</button>
                    <button type="button" class="insert-variable button" data-variable="position">{position}</button>
                    <button type="button" class="insert-variable button" data-variable="photo_title">{photo_title}</button>
                </div>
                <textarea id="winner_notification_template" name="photo_contest_email_settings[winner_notification_template]" rows="10" class="large-text"><?php echo esc_textarea(get_option('photo_contest_email_settings')['winner_notification_template'] ?? ''); ?></textarea>
                <button type="button" class="preview-template button" data-template="winner_notification"><?php _e('Preview', 'photo-contest'); ?></button>
            </div>
        </div>

        <?php submit_button(); ?>
    </form>

    <!-- Preview Modal -->
    <div id="template-preview-modal" class="modal" style="display:none;">
        <div class="modal-content">
            <span class="close-preview">&times;</span>
            <h2><?php _e('Email Preview', 'photo-contest'); ?></h2>
            <div id="template-preview-content"></div>
        </div>
    </div>
</div>
