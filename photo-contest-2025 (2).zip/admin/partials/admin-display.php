<?php if (!defined('ABSPATH')) exit; ?>

<div class="wrap photo-contest-admin">
    <h1>All Photo Contests</h1>

    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Title</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Submissions</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($contests)): ?>
                <?php foreach ($contests as $contest): ?>
                    <tr>
                        <td><?php echo esc_html($contest->title); ?></td>
                        <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($contest->start_date))); ?></td>
                        <td><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($contest->end_date))); ?></td>
                        <td><?php echo esc_html(ucfirst($contest->status)); ?></td>
                        <td><?php echo isset($contest->submission_count) ? esc_html($contest->submission_count) : '0'; ?></td>
                        <td>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=photo-contest-edit&id=' . $contest->id)); ?>" 
                               class="button button-small">Edit</a>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=photo-contest-submissions&contest_id=' . $contest->id)); ?>" 
                               class="button button-small">View Submissions</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No contests found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
