<?php
class Photo_Contest_Results {
    private $wpdb;
    private $submissions_table;
    private $votes_table;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->submissions_table = $wpdb->prefix . 'photo_submissions';
        $this->votes_table = $wpdb->prefix . 'photo_contest_votes';
        
        add_shortcode('photo_contest_results', array($this, 'render_results'));
    }

    public function render_results($atts) {
        $atts = shortcode_atts(array(
            'contest_id' => 0,
            'limit' => 3
        ), $atts);

        if (!$atts['contest_id']) {
            return '<p>Contest ID is required.</p>';
        }

        ob_start();
        include PHOTO_CONTEST_PATH . 'public/templates/contest-results.php';
        return ob_get_clean();
    }

    public function get_contest_winners($contest_id, $limit = 3) {
        return $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT * FROM {$this->submissions_table} 
            WHERE contest_id = %d 
            AND status = 'approved' 
            ORDER BY votes_count DESC 
            LIMIT %d",
            $contest_id,
            $limit
        ));
    }
}
