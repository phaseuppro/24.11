<?php
if (!defined('ABSPATH')) exit;

$message = isset($_GET['message']) ? $_GET['message'] : '';
$messages = [
    'created' => 'Contest created successfully.',
    'updated' => 'Contest updated successfully.',
    'deleted' => 'Contest deleted successfully.',
    'error' => 'An error occurred.'
];
?>

<div class="wrap photo-contest-admin">
    <?php if ($message && isset($messages[$message])): ?>
        <div class="notice notice-success is-dismissible">
            <p><?php echo esc_html($messages[$message]); ?></p>
        </div>
    <?php endif; ?>

    <h1 class="wp-heading-inline">Photo Contests</h1>
    <a href="<?php echo admin_url('admin.php?page=photo-contest-new'); ?>" class="page-title-action">Add New Contest</a>

    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Title</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Entries</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($contests as $contest): ?>
                <tr>
                    <td><?php echo esc_html($contest->title); ?></td>
                    <td><?php echo esc_html(date('Y-m-d', strtotime($contest->start_date))); ?></td>
                    <td><?php echo esc_html(date('Y-m-d', strtotime($contest->end_date))); ?></td>
                    <td><?php echo esc_html(ucfirst($contest->status)); ?></td>
                    <td>0</td>
                    <td>
                        <a href="<?php echo admin_url('admin.php?page=photo-contest-edit&id=' . $contest->id); ?>" class="button">Edit</a>
                        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display:inline;">
                            <input type="hidden" name="action" value="delete_photo_contest">
                            <input type="hidden" name="contest_id" value="<?php echo esc_attr($contest->id); ?>">
                            <?php wp_nonce_field('delete_photo_contest', 'photo_contest_nonce'); ?>
                            <button type="submit" class="button button-link-delete" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
