<?php
class Photo_Contest_Shortcodes {
    private $contest_manager;
    
    public function __construct() {
        require_once PHOTO_CONTEST_PATH . 'includes/class-photo-contest-manager.php';
        $this->contest_manager = new Photo_Contest_Manager();
        
        add_shortcode('photo_contest_submission', array($this, 'render_submission_form'));
        add_shortcode('photo_contest_gallery', array($this, 'render_contest_gallery'));
    }
    
    public function render_submission_form($atts) {
        $atts = shortcode_atts(array(
            'contest_id' => 0
        ), $atts);
        
        if (!is_user_logged_in()) {
            return '<p>Please <a href="' . wp_login_url(get_permalink()) . '">login</a> to submit your photo.</p>';
        }
        
        $contest = $this->contest_manager->get_contest($atts['contest_id']);
        if (!$contest) {
            return '<p>Contest not found.</p>';
        }
        
        ob_start();
        include PHOTO_CONTEST_PATH . 'public/templates/submission-form.php';
        return ob_get_clean();
    }
    
    public function render_contest_gallery($atts) {
        $atts = shortcode_atts(array(
            'contest_id' => 0,
            'columns' => 3
        ), $atts);
        
        $contest = $this->contest_manager->get_contest($atts['contest_id']);
        if (!$contest) {
            return '<p>Contest not found.</p>';
        }
        
        ob_start();
        include PHOTO_CONTEST_PATH . 'public/templates/contest-gallery.php';
        return ob_get_clean();
    }
}
