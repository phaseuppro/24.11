<?php
class Photo_Contest_Submission {
    private $wpdb;
    private $submissions_table;
    private $upload_dir;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->submissions_table = $wpdb->prefix . 'photo_submissions';
        $this->upload_dir = wp_upload_dir();

        add_action('admin_post_submit_photo_contest', array($this, 'handle_submission'));
        add_action('admin_post_nopriv_submit_photo_contest', array($this, 'handle_submission'));
    }

    public function handle_submission() {
        if (!isset($_POST['photo_contest_nonce']) || 
            !wp_verify_nonce($_POST['photo_contest_nonce'], 'submit_photo_contest')) {
            wp_die('Security check failed');
        }

        $contest_id = intval($_POST['contest_id']);
        $user_id = get_current_user_id();

        // Handle file upload
        $file = $_FILES['photo_file'];
        $upload_result = $this->handle_photo_upload($file);

        if (is_wp_error($upload_result)) {
            wp_die($upload_result->get_error_message());
        }

        $submission_data = array(
            'contest_id' => $contest_id,
            'user_id' => $user_id,
            'photo_url' => $upload_result['url'],
            'title' => sanitize_text_field($_POST['photo_title']),
            'description' => sanitize_textarea_field($_POST['photo_description']),
            'status' => 'pending',
            'created_at' => current_time('mysql')
        );

        $result = $this->wpdb->insert(
            $this->submissions_table,
            $submission_data,
            array('%d', '%d', '%s', '%s', '%s', '%s', '%s')
        );

        if ($result) {
            wp_redirect(add_query_arg('submitted', 'true', wp_get_referer()));
        } else {
            wp_die('Submission failed');
        }
        exit;
    }

    private function handle_photo_upload($file) {
        $allowed_types = array('image/jpeg', 'image/png', 'image/gif');
        
        if (!in_array($file['type'], $allowed_types)) {
            return new WP_Error('invalid_type', 'Invalid file type. Please upload a JPEG, PNG or GIF image.');
        }

        if ($file['size'] > 5242880) { // 5MB max
            return new WP_Error('invalid_size', 'File too large. Maximum size is 5MB.');
        }

        $upload = wp_handle_upload($file, array('test_form' => false));

        if (isset($upload['error'])) {
            return new WP_Error('upload_error', $upload['error']);
        }

        return $upload;
    }

    public function get_submissions($contest_id) {
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->submissions_table} WHERE contest_id = %d ORDER BY created_at DESC",
                $contest_id
            )
        );
    }
}
