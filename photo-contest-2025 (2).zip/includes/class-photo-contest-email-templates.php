<?php
class Photo_Contest_Email_Templates {
    public function get_submission_approved_template($user_name, $contest_title) {
        $template = '
        <div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
            <h2 style="color: #0073aa;">Photo Submission Approved!</h2>
            <p>Hello ' . esc_html($user_name) . ',</p>
            <p>Great news! Your photo submission for the contest "' . esc_html($contest_title) . '" has been approved.</p>
            <p>Your photo is now visible in the contest gallery and is eligible for voting.</p>
            <p>Best regards,<br>The Contest Team</p>
        </div>';
        
        return $template;
    }

    public function get_winner_notification_template($user_name, $contest_title, $position) {
        $template = '
        <div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
            <h2 style="color: #0073aa;">Congratulations! You\'re a Winner! 🏆</h2>
            <p>Hello ' . esc_html($user_name) . ',</p>
            <p>We\'re excited to announce that your photo has won ' . $this->get_position_text($position) . ' place in the "' . esc_html($contest_title) . '" contest!</p>
            <p>Thank you for participating and sharing your amazing work with us.</p>
            <p>Best regards,<br>The Contest Team</p>
        </div>';
        
        return $template;
    }

    public function get_admin_notification_template($contest_title, $submission_details) {
        $template = '
        <div style="max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif;">
            <h2 style="color: #0073aa;">New Photo Submission</h2>
            <p>A new photo has been submitted to the contest "' . esc_html($contest_title) . '".</p>
            <div style="background: #f5f5f5; padding: 15px; margin: 15px 0;">
                <p><strong>Submission Details:</strong></p>
                <ul>
                    <li>Title: ' . esc_html($submission_details['title']) . '</li>
                    <li>Submitted by: ' . esc_html($submission_details['user_name']) . '</li>
                    <li>Date: ' . esc_html($submission_details['date']) . '</li>
                </ul>
            </div>
            <p>Please review this submission in the admin panel.</p>
        </div>';
        
        return $template;
    }

    private function get_position_text($position) {
        switch ($position) {
            case 1:
                return 'first';
            case 2:
                return 'second';
            case 3:
                return 'third';
            default:
                return $position . 'th';
        }
    }
}
