<?php
class Photo_Contest_Manager {
    private $wpdb;
    private $contests_table;
    private $submissions_table;
    private $votes_table;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->contests_table = $wpdb->prefix . 'photo_contests';
        $this->submissions_table = $wpdb->prefix . 'photo_contest_submissions';
        $this->votes_table = $wpdb->prefix . 'photo_contest_votes';
    }

    public function create_contest($data) {
        return $this->wpdb->insert(
            $this->contests_table,
            array(
                'title' => sanitize_text_field($data['contest_title']),
                'description' => sanitize_textarea_field($data['contest_description']),
                'start_date' => $data['start_date'],
                'end_date' => $data['end_date'],
                'status' => 'draft',
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s')
        );
    }

    public function get_all_contests() {
        return $this->wpdb->get_results(
            "SELECT * FROM {$this->contests_table} ORDER BY created_at DESC"
        );
    }

    public function get_contest($id) {
        return $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->contests_table} WHERE id = %d",
                $id
            )
        );
    }

    public function update_contest($id, $data) {
        return $this->wpdb->update(
            $this->contests_table,
            array(
                'title' => sanitize_text_field($data['contest_title']),
                'description' => sanitize_textarea_field($data['contest_description']),
                'start_date' => $data['start_date'],
                'end_date' => $data['end_date'],
                'status' => $data['status']
            ),
            array('id' => $id),
            array('%s', '%s', '%s', '%s', '%s'),
            array('%d')
        );
    }

    public function delete_contest($id) {
        return $this->wpdb->delete(
            $this->contests_table,
            array('id' => $id),
            array('%d')
        );
    }

    public function get_contest_submissions($contest_id, $args = []) {
        $defaults = [
            'status' => '',
            'orderby' => 'submission_date',
            'order' => 'DESC'
        ];
        
        $args = wp_parse_args($args, $defaults);
        
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->submissions_table} 
                WHERE contest_id = %d 
                ORDER BY submission_date DESC",
                $contest_id
            )
        );
    }

    public function approve_submission($submission_id) {
        return $this->wpdb->update(
            $this->submissions_table,
            ['status' => 'approved'],
            ['id' => $submission_id],
            ['%s'],
            ['%d']
        );
    }

    public function reject_submission($submission_id) {
        return $this->wpdb->update(
            $this->submissions_table,
            ['status' => 'rejected'],
            ['id' => $submission_id],
            ['%s'],
            ['%d']
        );
    }

    public function search_submissions($contest_id, $search_term) {
        return $this->wpdb->get_results(
            $this->wpdb->prepare(
                "SELECT * FROM {$this->submissions_table} 
                WHERE contest_id = %d 
                AND (title LIKE %s OR participant_name LIKE %s)",
                $contest_id,
                '%' . $this->wpdb->esc_like($search_term) . '%',
                '%' . $this->wpdb->esc_like($search_term) . '%'
            )
        );
    }

    public function get_submission_votes($submission_id) {
        return $this->wpdb->get_var(
            $this->wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->votes_table} WHERE submission_id = %d",
                $submission_id
            )
        );
    }

    public function add_vote($submission_id, $user_id) {
        return $this->wpdb->insert(
            $this->votes_table,
            [
                'submission_id' => $submission_id,
                'user_id' => $user_id,
                'created_at' => current_time('mysql')
            ],
            ['%d', '%d', '%s']
        );
    }
}
